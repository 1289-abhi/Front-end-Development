//variables
const courses=document.querySelector('#courses-list')
      shoppingCartContent=document.querySelector("#cart-content tbody"),
      clearCartBtn=document.querySelector('#clear-cart');



//listeners
loadEventListeners();
function loadEventListeners(){
  courses.addEventListener('click',buyCourse);

  //when the remove button is clicked
  shoppingCartContent.addEventListener('click',removeCourse);

  //clear cart button
  clearCartBtn.addEventListener('click',clearCart);

  //document ready
  document.addEventListener('DOMContentLoaded', getFromLocalStorage);
}




//functions
function buyCourse(e){
  //use the delegation to find the course that was added
  e.preventDefault();
  if(e.target.classList.contains('add-to-cart')){
    //read the course values
    const course=e.target.parentElement.parentElement;
    //read the values
    getCourseInfo(course);
  }
}
//reads the HTML elements of the selected course
function getCourseInfo(course){
  //create and object with course data;
  const courseInfo={
    image: course.querySelector('img').src,
    title: course.querySelector('h4').textContent,
    price: course.querySelector('.price span').textContent,
    id: course.querySelector('a').getAttribute('data-id')
  };

  //insert into cart
  addIntoCart(courseInfo);
}
//display the selected course into the shopping cart.
function addIntoCart(course) {
  //create a <tr>
  const row=document.createElement('tr');
  //build the template
  row.innerHTML=`
  <tr>
    <td>
      <img src=${course.image} width=100px>
    </td>
    <td>${course.title}</td>
    <td>${course.price}</td>
    <td>
      <a href="#" class="remove" data-id="${course.id}">X</a>
    </td>
  </tr>`;

  //add into the shopping cart
  shoppingCartContent.appendChild(row);

  //add course into storage
  saveIntoStorage(course);
}

//add the courses into the local storage
function saveIntoStorage(course) {
  let courses=getCoursesFromStorage();
  //add the course into the array
  courses.push(course);
  localStorage.setItem('courses', JSON.stringify(courses));
}

//get courses from the storage
function getCoursesFromStorage() {
  let courses;
  //if something exists in the storage we get the value otherwise create and empty array
  if (localStorage.getItem('courses') === null) {
    courses=[];
  }
  else {
    courses=JSON.parse(localStorage.getItem('courses'));
  }
  return courses;
}
//remove course from the DOM
function removeCourse(e) {
  let course, courseId;
  if (e.target.classList.contains('remove')) {
    e.target.parentElement.parentElement.remove();
    course=e.target.parentElement.parentElement;
    courseId=course.querySelector('a').getAttribute('data-id');
  }
  //remove the course from local storage
  removeCourseLS(courseId);

}
function removeCourseLS(id) {
  let coursesLS=getCoursesFromStorage();

  coursesLS.forEach((course, i) => {
    if (course.id===id) {
      coursesLS.splice(i,1);
    }
  });
  localStorage.setItem('courses',JSON.stringify(coursesLS));

}

//clear the shopping cart
function clearCart() {
  shoppingCartContent.innerHTML='';

  //clear from local storage
  localStorage.clear();
}
//loads when document is ready and prints courses into the shopping cart
function getFromLocalStorage() {
  let coursesLS = getCoursesFromStorage();
  coursesLS.forEach((course, i) => {
    //create tr
    const row=document.createElement('tr');

    row.innerHTML=`
    <tr>
      <td>
        <img src=${course.image} width=100px>
      </td>
      <td>${course.title}</td>
      <td>${course.price}</td>
      <td>
        <a href="#" class="remove" data-id="${course.id}">X</a>
      </td>
    </tr>`;
    shoppingCartContent.appendChild(row);
  });

}
