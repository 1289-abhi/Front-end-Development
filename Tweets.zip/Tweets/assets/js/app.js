//variables
const tweetList=document.getElementById('tweet-list');



//event listeners
eventlisteners();

function eventlisteners(){
  //form submissions
  document.querySelector("#form").addEventListener('submit',newTweet);

  //remove tweet from the list
  tweetList.addEventListener('click',removeTweet);

  document.addEventListener('DOMContentLoaded',localStorageOnLoad);
}




//functions
function newTweet(e){
  e.preventDefault();

  //read the text area
  const tweet=document.querySelector('#tweet').value;

  //create the remove button
  const removeBtn=document.createElement('a');
  removeBtn.classList='remove-tweet';
  removeBtn.textContent='x';


  //create an list element
  const li=document.createElement('li');
  li.textContent=tweet;

  //add remove button in each tweet
  li.appendChild(removeBtn);

  //add to the list
  tweetList.appendChild(li);
//add to local storage
  addTweetLocalStorage(tweet);
  alert("tweet Added");
  this.reset();

}


//removes the tweet from the dom functions
function removeTweet(e) {
  if(e.target.classList.contains('remove-tweet')){
    e.target.parentElement.remove();
  }
  removeFromStorage(e.target.parentElement.textContent);
}

//adds the tweets in local storage

function addTweetLocalStorage(tweet) {
  let tweets=getTweetsFromStorage();
  tweets.push(tweet);
  localStorage.setItem('tweets',JSON.stringify(tweets));
}
function getTweetsFromStorage() {
  let tweets;
  const tweetsLS=localStorage.getItem('tweets');
  if (tweetsLS=== null) {
    tweets=[];
  }
  else {
    tweets=JSON.parse(tweetsLS);
  }
  return tweets;
}
function localStorageOnLoad() {
  let tweets=getTweetsFromStorage();
  tweets.forEach(function(tweet) {
    const removeBtn=document.createElement('a');
    removeBtn.classList='remove-tweet';
    removeBtn.textContent='x';


    //create an list element
    const li=document.createElement('li');
    li.textContent=tweet;

    //add remove button in each tweet
    li.appendChild(removeBtn);

    //add to the list
    tweetList.appendChild(li);
  });
}

function removeFromStorage(tweet) {
  let tweets=getTweetsFromStorage();
  const tweetDelete=tweet.substring(0,tweet.length-1);
  tweets.forEach((tweetLS,i)=> {
    if (tweetDelete===tweetLS) {
      tweets.splice(i,1);
    }
  });
  localStorage.setItem('tweets',JSON.stringify(tweets));
}
